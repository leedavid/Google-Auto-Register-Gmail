/**
 * define uiStyleOptions 
 * 
 ***/
cr.define('options', function() {
    var OptionsPage = options.OptionsPage;

    function UIStyleOptions() {
        OptionsPage.call(this, 'uiStyle', templateData.uiStylePageTabTitle, 'uiStylePage');
    }

    cr.addSingletonGetter(UIStyleOptions);
    
    UIStyleOptions.prototype = {
        __proto__: options.OptionsPage.prototype,

        initializePage: function(){
            OptionsPage.prototype.initializePage.call(this);

            Preferences.getInstance().addEventListener('browser.use_custom_font_size', function(e) {
              $$('[pref="browser.default_font_size"]').attr('disabled', (e.value || {}).value != 1);
              $$('#fontsize_option_tips').css('display', (e.value || {}).value != 1 ? 'none':'');
            });

            Preferences.getInstance().addEventListener('browser.default_font_size', function(e) {
              $$('#custom_fontsize_preview').css('font-size', (e.value || {}).value + 'pt');
            });
            }
        };

    return {
        UIStyleOptions: UIStyleOptions
    };
});