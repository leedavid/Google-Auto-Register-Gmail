/**
 * define tabOptionsPage 
 * 
 ***/
cr.define('options', function() {
  var OptionsPage = options.OptionsPage;

  function TabOptionsPage() {
    OptionsPage.call(this, 'tabOptions', templateData.tabOptionsPageTabTitle, 'tabOptionsPage');
  }

  cr.addSingletonGetter(TabOptionsPage);
  
  TabOptionsPage.prototype = {
    __proto__: options.OptionsPage.prototype,
    
    initializePage: function(){
      OptionsPage.prototype.initializePage.call(this);
    },
  };

  return {
    TabOptionsPage: TabOptionsPage
  };
});
